/*
============================================
; Title:  service.js
; Author: Brock Hemsouvanh
; Date:   11/15/2023
; Description: Create module for Service/Client object exports.
;===========================================
*/ 

// PLACEHOLDER FOR CODE IDEA