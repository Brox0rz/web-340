/*
============================================
; Title:  service.js
; Author: Brock Hemsouvanh
; Date:   11/12/2023
; Description: Create module for Service/Client object exports.
;===========================================
*/ 
