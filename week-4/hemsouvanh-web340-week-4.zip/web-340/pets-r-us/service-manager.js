/*
============================================
; Title:  service-manager.js
; Author: Brock Hemsouvanh
; Date:   11/12/2023
; Description: Create array of services, clients, and functions to call them for a pet care website.
;===========================================
*/ 

